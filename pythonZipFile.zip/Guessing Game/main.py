import random

def guess_the_number():
    # Generate a random number between 1 and 100
    target_number = random.randint(1, 100)

    print("Guess the Number Game")
    print("======================")

    attempts = 0

    while True:
        # Get user guess
        user_guess = int(input("Enter your guess (between 1 and 100): "))
        attempts += 1

        # Check if the guess is correct
        if user_guess == target_number:
            print(f"Congratulations! You guessed the correct number {target_number} in {attempts} attempts.")
            break
        elif user_guess < target_number:
            print("Too low! Try again.")
        else:
            print("Too high! Try again.")

if __name__ == "__main__":
    guess_the_number()
