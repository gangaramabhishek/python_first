def reverse_string(input_str):
    return input_str[::-1]


input_string = input("Enter any word :" )
reversed_string = reverse_string(input_string)
print(reversed_string)