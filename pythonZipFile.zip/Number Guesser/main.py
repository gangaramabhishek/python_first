import random

def number_guessing_game():
    # Set the range for the random number
    lower_limit = 1
    upper_limit = 100

    # Generate a random number within the specified range
    target_number = random.randint(lower_limit, upper_limit)

    print(f"Number Guessing Game (between {lower_limit} and {upper_limit})")
    print("==============================================================")

    attempts = 0

    while True:
        # Get user guess
        user_guess = int(input("Enter your guess: "))

        # Validate user input
        if lower_limit <= user_guess <= upper_limit:
            attempts += 1

            # Check if the guess is correct
            if user_guess == target_number:
                print(f"Congratulations! You guessed the correct number {target_number} in {attempts} attempts.")
                break
            elif user_guess < target_number:
                print("Too low! Try again.")
            else:
                print("Too high! Try again.")
        else:
            print(f"Please enter a number between {lower_limit} and {upper_limit}.")

if __name__ == "__main__":
    number_guessing_game()
