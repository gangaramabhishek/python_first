import string

def count_word_occurrences(file_path):
    word_counts = {}

    try:
        with open(file_path, 'r') as file:
            # Read the file and process each line
            for line in file:
                # Remove punctuation and convert to lowercase
                line = line.translate(str.maketrans("", "", string.punctuation))
                words = line.lower().split()

                # Count occurrences of each word
                for word in words:
                    if word in word_counts:
                        word_counts[word] += 1
                    else:
                        word_counts[word] = 1
    except FileNotFoundError:
        return "File not found. Please provide a valid file path."

    # Display results in alphabetical order
    sorted_word_counts = sorted(word_counts.items(), key=lambda x: x[0])
    for word, count in sorted_word_counts:
        print(f"{word}: {count}")

# Example usage:
file_path = input("Enter the path to the text file: ")
count_word_occurrences(file_path)
