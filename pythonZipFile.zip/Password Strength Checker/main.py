import string

def evaluate_password_strength(password):
    # Check length
    if len(password) < 8:
        return "Weak: Password should be at least 8 characters long."

    # Check for uppercase and lowercase letters
    if not any(char.isupper() for char in password) or not any(char.islower() for char in password):
        return "Weak: Password should contain both uppercase and lowercase letters."

    # Check for digits
    if not any(char.isdigit() for char in password):
        return "Weak: Password should contain at least one digit."

    # Check for special characters
    special_characters = set(string.punctuation)
    if not any(char in special_characters for char in password):
        return "Weak: Password should contain at least one special character."

    # If all checks passed, the password is strong
    return "Strong: Password meets all criteria."

# Example usage:
user_password = input("Enter your password: ")
strength_evaluation = evaluate_password_strength(user_password)
print(strength_evaluation)
