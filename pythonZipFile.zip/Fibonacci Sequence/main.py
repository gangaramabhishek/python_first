def generate_fibonacci_sequence(terms):
    fibonacci_sequence = []
    
    if terms <= 0:
        return "Please enter a positive integer for the number of terms."

    # First two terms of the Fibonacci sequence
    a, b = 0, 1
    fibonacci_sequence.append(a)
    fibonacci_sequence.append(b)

    # Generate the Fibonacci sequence up to the specified number of terms
    for _ in range(2, terms):
        c = a + b
        fibonacci_sequence.append(c)
        a, b = b, c

    return fibonacci_sequence

# Example usage:
try:
    num_of_terms = int(input("Enter the number of terms for the Fibonacci sequence: "))
    result = generate_fibonacci_sequence(num_of_terms)
    print(f"Fibonacci Sequence up to {num_of_terms} terms: {result}")
except ValueError:
    print("Please enter a valid positive integer.")
